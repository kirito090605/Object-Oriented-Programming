// The Greeting class declaration.
public class Greeting {
  private String salutation;

  public Greeting(String s) {
    salutation = s;
  }
  
  public void greet(String whom) {
    System.out.println(salutation + " " + whom);
  }
}
